﻿
namespace Library_system
{
    partial class Query_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Query_txt = new System.Windows.Forms.TextBox();
            this.Query_View = new System.Windows.Forms.DataGridView();
            this.Query_btn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.queriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الكتابالاكثرمبيعاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.q8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.Query_View)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Query_txt
            // 
            this.Query_txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Query_txt.Font = new System.Drawing.Font("Tahoma", 15F);
            this.Query_txt.Location = new System.Drawing.Point(41, 44);
            this.Query_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Query_txt.Multiline = true;
            this.Query_txt.Name = "Query_txt";
            this.Query_txt.Size = new System.Drawing.Size(726, 158);
            this.Query_txt.TabIndex = 0;
            this.Query_txt.TextChanged += new System.EventHandler(this.Query_txt_TextChanged);
            // 
            // Query_View
            // 
            this.Query_View.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.Query_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Query_View.Location = new System.Drawing.Point(41, 222);
            this.Query_View.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Query_View.Name = "Query_View";
            this.Query_View.RowHeadersWidth = 51;
            this.Query_View.Size = new System.Drawing.Size(984, 318);
            this.Query_View.TabIndex = 1;
            this.Query_View.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Query_View_CellContentClick);
            // 
            // Query_btn
            // 
            this.Query_btn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Query_btn.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Query_btn.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Query_btn.Location = new System.Drawing.Point(809, 80);
            this.Query_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Query_btn.Name = "Query_btn";
            this.Query_btn.Size = new System.Drawing.Size(216, 89);
            this.Query_btn.TabIndex = 2;
            this.Query_btn.Text = "Excute Query";
            this.Query_btn.UseVisualStyleBackColor = false;
            this.Query_btn.Click += new System.EventHandler(this.Query_btn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.queriesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1066, 34);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // queriesToolStripMenuItem
            // 
            this.queriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الكتابالاكثرمبيعاToolStripMenuItem,
            this.q2ToolStripMenuItem,
            this.q3ToolStripMenuItem,
            this.q4ToolStripMenuItem,
            this.q5ToolStripMenuItem,
            this.q6ToolStripMenuItem,
            this.q7ToolStripMenuItem,
            this.q8ToolStripMenuItem});
            this.queriesToolStripMenuItem.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.queriesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.queriesToolStripMenuItem.Name = "queriesToolStripMenuItem";
            this.queriesToolStripMenuItem.Size = new System.Drawing.Size(173, 30);
            this.queriesToolStripMenuItem.Text = "Saved Queries";
            this.queriesToolStripMenuItem.Click += new System.EventHandler(this.queriesToolStripMenuItem_Click);
            // 
            // الكتابالاكثرمبيعاToolStripMenuItem
            // 
            this.الكتابالاكثرمبيعاToolStripMenuItem.Name = "الكتابالاكثرمبيعاToolStripMenuItem";
            this.الكتابالاكثرمبيعاToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.الكتابالاكثرمبيعاToolStripMenuItem.Text = "Q1";
            this.الكتابالاكثرمبيعاToolStripMenuItem.Click += new System.EventHandler(this.الكتابالاكثرمبيعاToolStripMenuItem_Click);
            // 
            // q2ToolStripMenuItem
            // 
            this.q2ToolStripMenuItem.Name = "q2ToolStripMenuItem";
            this.q2ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q2ToolStripMenuItem.Text = "Q2";
            this.q2ToolStripMenuItem.Click += new System.EventHandler(this.q2ToolStripMenuItem_Click);
            // 
            // q3ToolStripMenuItem
            // 
            this.q3ToolStripMenuItem.Name = "q3ToolStripMenuItem";
            this.q3ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q3ToolStripMenuItem.Text = "Q3";
            this.q3ToolStripMenuItem.Click += new System.EventHandler(this.q3ToolStripMenuItem_Click);
            // 
            // q4ToolStripMenuItem
            // 
            this.q4ToolStripMenuItem.Name = "q4ToolStripMenuItem";
            this.q4ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q4ToolStripMenuItem.Text = "Q4";
            this.q4ToolStripMenuItem.Click += new System.EventHandler(this.q4ToolStripMenuItem_Click);
            // 
            // q5ToolStripMenuItem
            // 
            this.q5ToolStripMenuItem.Name = "q5ToolStripMenuItem";
            this.q5ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q5ToolStripMenuItem.Text = "Q5";
            this.q5ToolStripMenuItem.Click += new System.EventHandler(this.q5ToolStripMenuItem_Click);
            // 
            // q6ToolStripMenuItem
            // 
            this.q6ToolStripMenuItem.Name = "q6ToolStripMenuItem";
            this.q6ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q6ToolStripMenuItem.Text = "Q6";
            this.q6ToolStripMenuItem.Click += new System.EventHandler(this.q6ToolStripMenuItem_Click_1);
            // 
            // q7ToolStripMenuItem
            // 
            this.q7ToolStripMenuItem.Name = "q7ToolStripMenuItem";
            this.q7ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q7ToolStripMenuItem.Text = "Q7";
            this.q7ToolStripMenuItem.Click += new System.EventHandler(this.q7ToolStripMenuItem_Click);
            // 
            // q8ToolStripMenuItem
            // 
            this.q8ToolStripMenuItem.Name = "q8ToolStripMenuItem";
            this.q8ToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.q8ToolStripMenuItem.Text = "Q8";
            this.q8ToolStripMenuItem.Click += new System.EventHandler(this.q8ToolStripMenuItem_Click);
            // 
            // Query_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Library_system.Properties.Resources._20407be9_28a6_46aa_bcf2_5d46b595c62e;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1066, 554);
            this.Controls.Add(this.Query_btn);
            this.Controls.Add(this.Query_View);
            this.Controls.Add(this.Query_txt);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Query_Form";
            this.Text = "Query_Form";
            this.Load += new System.EventHandler(this.Query_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Query_View)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Query_txt;
        private System.Windows.Forms.DataGridView Query_View;
        private System.Windows.Forms.Button Query_btn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem queriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الكتابالاكثرمبيعاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem q8ToolStripMenuItem;
    }
}