﻿
namespace Library_system
{
    partial class Login_Author
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Author_pass_in = new System.Windows.Forms.TextBox();
            this.Author_name_in = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.button1.Location = new System.Drawing.Point(303, 295);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 51);
            this.button1.TabIndex = 19;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Author_pass_in
            // 
            this.Author_pass_in.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Author_pass_in.Location = new System.Drawing.Point(420, 187);
            this.Author_pass_in.Name = "Author_pass_in";
            this.Author_pass_in.PasswordChar = '*';
            this.Author_pass_in.Size = new System.Drawing.Size(191, 38);
            this.Author_pass_in.TabIndex = 18;
            // 
            // Author_name_in
            // 
            this.Author_name_in.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Author_name_in.Location = new System.Drawing.Point(420, 132);
            this.Author_name_in.Name = "Author_name_in";
            this.Author_name_in.Size = new System.Drawing.Size(191, 38);
            this.Author_name_in.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(177, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 40);
            this.label3.TabIndex = 21;
            this.label3.Text = "Password";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(151, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 51);
            this.label4.TabIndex = 20;
            this.label4.Text = "User Name";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Login_Author
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Library_system.Properties.Resources._20407be9_28a6_46aa_bcf2_5d46b595c62e;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(828, 476);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Author_pass_in);
            this.Controls.Add(this.Author_name_in);
            this.Font = new System.Drawing.Font("Tahoma", 15F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.Name = "Login_Author";
            this.Text = "Login_Author";
            this.Load += new System.EventHandler(this.Login_Author_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Author_pass_in;
        private System.Windows.Forms.TextBox Author_name_in;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}