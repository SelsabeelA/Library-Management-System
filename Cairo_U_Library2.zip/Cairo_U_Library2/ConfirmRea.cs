﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_system
{
    public partial class ConfirmRea : Form
    {
        public ConfirmRea()
        {
            InitializeComponent();
        }

        private void ConfirmRea_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'library2DataSet.BOOK' table. You can move, or remove it, as needed.
            this.bOOKTableAdapter.Fill(this.library2DataSet.BOOK);
            // TODO: This line of code loads data into the 'library2DataSet8.BOOK' table. You can move, or remove it, as needed.


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show("The purchase was completed successfully \n \n Thank You For Your Time   ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Main_Reader mr = new Main_Reader();
            mr.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReaderBook Rb = new ReaderBook();
            Rb.Show();
            this.Hide();
        }
    }
}
