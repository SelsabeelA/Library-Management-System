﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_system
{
    public partial class MainForAuthor : Form
    {
        public MainForAuthor()
        {
            InitializeComponent();
        }

        private void MainForAuthor_Load(object sender, EventArgs e)
        {

        }

      

        private void button1_Click_1(object sender, EventArgs e)
        {
            ReaderBook re = new ReaderBook();
            re.Show();

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Add_Book ab = new Add_Book();
            ab.Show();
        }
    }
}
