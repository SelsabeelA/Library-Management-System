﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_system
{
    public partial class Add_Book : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-MUVOJ1E\SQLEXPRESS;Initial Catalog=LibraryManagement;Integrated Security=True");
        public Add_Book()
        {
            InitializeComponent();
        }

        private void Add_Book_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            conn.Open();

        }

        private void Add_Click(object sender, EventArgs e)
        {
            // conn.Open();
            string sql = "INSERT INTO BOOK (ISBN, TITLE, PUBLICATIONYEAR) VALUES (@ISBN, @BOOK_NAME, @BOOK_date)";
            string sql2 = "INSERT INTO BOOKCOPY (BOOKCOPYID, ISBN, AVAILABILITY, DAMAGED, EDITION) VALUES (@BOOKCOPYID, @ISBN, 1, @Damaged, @Edition)";
            string sql3 = "INSERT INTO WRITTEN_BY (ISBN, AUTHORID) VALUES (@ISBN, @AUTHOR_NAME)";
            string sql5 = "INSERT INTO IS_OF_KIND (ISBN, CATEGORYID) VALUES (@ISBN, @CATEGORY)";

            SqlCommand cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@ISBN", int.Parse(isbn.Text));
            cmd.Parameters.AddWithValue("@BOOK_NAME", Book_Name.Text);
            cmd.Parameters.AddWithValue("@BOOK_date", Book_Date.Text);

            cmd.ExecuteNonQuery();

            // Execute the second query
            SqlCommand cmd2 = new SqlCommand(sql2, conn);
            cmd2.Parameters.AddWithValue("@BOOKCOPYID", float.Parse(bookcopyid.Text));
            cmd2.Parameters.AddWithValue("@ISBN", int.Parse(isbn.Text));
            cmd2.Parameters.AddWithValue("@Damaged", int.Parse(damaged.Text));
            cmd2.Parameters.AddWithValue("@Edition", int.Parse(edition.Text));

            cmd2.ExecuteNonQuery();

            // Execute the third query
            SqlCommand cmd3 = new SqlCommand(sql3, conn);
            cmd3.Parameters.AddWithValue("@ISBN", int.Parse(isbn.Text));
            cmd3.Parameters.AddWithValue("@AUTHOR_NAME", Auther_Name.Text);

            cmd3.ExecuteNonQuery();

            // Execute the fifth query
            SqlCommand cmd5 = new SqlCommand(sql5, conn);
            cmd5.Parameters.AddWithValue("@ISBN", int.Parse(isbn.Text));
            cmd5.Parameters.AddWithValue("@CATEGORY", Category.Text);

            cmd5.ExecuteNonQuery();

            conn.Close();

            isbn.Text = "";
            Auther_Name.Text = "";
            Book_Name.Text = "";
            Book_Date.Text = "";
            bookcopyid.Text = "";
            Category.Text = "";

            MessageBox.Show("Book added successfully");
            this.Hide();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Auther_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void Price_TextChanged(object sender, EventArgs e)
        {

        }

        private void Category_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
