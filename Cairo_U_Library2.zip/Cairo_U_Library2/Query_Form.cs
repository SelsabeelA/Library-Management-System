﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_system
{
    public partial class Query_Form : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-MUVOJ1E\SQLEXPRESS;Initial Catalog=LibraryManagement;Integrated Security=True");
        SqlDataAdapter da;
        DataSet ds;


        public Query_Form()
        {
            InitializeComponent();
        }

        private void Query_Form_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            conn.Open();

        }

        private void Query_btn_Click(object sender, EventArgs e)
        {
            string query = Query_txt.Text;
            da = new SqlDataAdapter(query, conn);
            ds = new DataSet();
            da.Fill(ds);
            conn.Close();

            if(ds.Tables[0].Rows.Count != 0)
            {
                Query_View.DataSource = ds.Tables[0];
            }
        }

        private void الكتابالاكثرمبيعاToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

            string msgtext = "SELECT * FROM BOOK;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }


        private void queriesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void detailsAboutSavedQueriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void q2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM WRITTEN_BY;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM [USER];";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM CATEGORY;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM ADMIN;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //string msgtext = "SELECT * FROM Book_information;";
            //if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            //{ Clipboard.SetText(msgtext); }
        }

        private void Query_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Query_View_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void q6ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM BOOKCOPY;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM AUTHOR;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void q8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msgtext = "SELECT * FROM BORROWING;";
            if (MessageBox.Show(msgtext, "press ok to copy to Clipboard", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }
    }
}
